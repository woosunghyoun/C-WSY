﻿#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
#include <conio.h>
#include <Windows.h>

using namespace std;

struct Hero
{
	int fullHp;
	int myHp;
	int myGold = 0;
	int vecX = 0;
	int vecY = 0;
	string heroName;
};

struct Dungeon
{
	string monsterAtk[3] = { "가위", "바위", "보" };
	string myAttack[3] = { "가위", "바위", "보" };
	string diffLev;
	int monsterNum;
	int monsterPower;
};

struct Shop
{
	int potionCost[4] = { 300, 200, 100, 50 };
	int usePotion[4] = {100, 30, 20, 10 };
};

int main()
{
	int wasdBoard;
	int myAtk;

	Hero myHero;
	Dungeon myDungeon;
	Shop goShop;

	cout << "         ★★★★★★★★" << endl;
	cout << "     ★★★★★★★★★★★★" << endl;
	cout << "   ★★★★★★★★★★★★★★" << endl;
	cout << " ★★★★★★★★★★★★★★★★" << endl;
	cout << "★★★      ★★★★       ★★★" << endl;
	cout << "★★       ★★★★★       ★★★" << endl;
	cout << "★★★★★★★★ ★★★★★★★★★" << endl;
	cout << "★★★★★영웅은 절차적★★★★★★" << endl;
	cout << "★★★★★★★★★★★★★★★★★ " << endl;
	cout << " ★★★★★★★★★★★★★★★★ " << endl;
	cout << "  ★★★  ★★★ ★★★  ★★★ " << endl;
	cout << "   ★★★ ★★★ ★★★ ★★★" << endl;
	cout << "     ★★ ★★★ ★★★ ★★" << endl;
	cout << "--------게임을 시작합니다--------" << endl;
	cout << endl;
	cout << "영웅의 이름을 입력해주세요 : ";
	cin >> myHero.heroName;
	cout << "게임의 난이도를 설정해주세요 (1.easy / 2.normal / 3.hard) " << endl;
	cin >> myDungeon.diffLev;
	cout << myHero.heroName << "님 " << myDungeon.diffLev << "모드로 진행합니다." << endl;

	if (myDungeon.diffLev == "easy")
	{
		myHero.fullHp = 100;
		myHero.myHp = 100;
		myDungeon.monsterNum = 3;
		myDungeon.monsterPower = 10;
	}
	else if (myDungeon.diffLev == "normal")
	{
		myHero.fullHp = 90;
		myHero.myHp = 90;
		myDungeon.monsterNum = 5;
		myDungeon.monsterPower = 15;
	}
	else if (myDungeon.diffLev == "hard")
	{
		myHero.fullHp = 80;
		myHero.myHp = 80;
		myDungeon.monsterNum = 7;
		myDungeon.monsterPower = 20;
	}
	////////////////////////////////앱과 이동/////////////////////////////////////////
	while (myDungeon.monsterNum > 0)
	{
		if (myHero.myHp <= 0) { break; }
		//////////몬스터가 도망다님
		srand(time(NULL));
		int xRandom = rand() % 10;
		int yRandom = rand() % 10;
		int dropGold = (rand() % (100 - 1 + 1) + 1);
		/////////////////////////
		system("cls");
		cout << "★★" << myDungeon.diffLev << " mode★★" << endl;
		cout << endl;
		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				if (i == myHero.vecX and j == myHero.vecY) cout << 'O';

				else if (i == xRandom and j == yRandom) cout << 'E';

				else cout << '#';
			}
			cout << endl;
		}
		//////////키 입력과 이동///////////
		wasdBoard = _getch();
		switch (wasdBoard)
		{
		case 'w': case'W':
			if (myHero.vecX > 0) myHero.vecX = myHero.vecX - 1; break;
		case 'a': case 'A':
			if (myHero.vecY > 0) myHero.vecY = myHero.vecY - 1; break;
		case 's': case 'S':
			if (myHero.vecX < 9) myHero.vecX = myHero.vecX + 1; break;
		case 'd': case 'D':
			if (myHero.vecY < 9) myHero.vecY = myHero.vecY + 1; break;
		}
		////////////////////////////////////몬스터 조우////////////////////////////////////
		while (myHero.vecX == xRandom and myHero.vecY == yRandom)
		{
			int atkNum = rand() % 2;
			myDungeon.monsterAtk[atkNum]; 
			cout << "현재 체력 : " << myHero.myHp << " /소지 골드 : " << myHero.myGold << endl;
			cout << "공격(1.가위, 2.바위, 3.보)을 입력하세요 : ";
			cin >> myAtk;
			myDungeon.myAttack[myAtk];
			if (myAtk > 3)
			{
				cout << "다시 입력하세요." << endl;
				cout << endl;
			}
			else if (myDungeon.monsterAtk[atkNum] == myDungeon.myAttack[myAtk - 1])
			{
				cout << "몬스터의 공격은 : " << myDungeon.monsterAtk[atkNum] << endl;
				cout << "비겼습니다." << endl;
				cout << endl;
			}
			else if (myDungeon.monsterAtk[atkNum] == myDungeon.myAttack[myAtk - 2])
			{
				myDungeon.monsterNum--;
				myHero.myGold += dropGold;
				int selecNum;
				cout << "몬스터의 공격은 : " << myDungeon.monsterAtk[atkNum] << endl;
				cout << "이겼습니다. 남은 몬스터 마리수 : " << myDungeon.monsterNum << endl;
				cout << endl;
				Sleep(1000);
				/////////////////////////////////////상점 포션////////////////////////////////////////
				if (myDungeon.monsterNum > 0)
				{
					system("cls");
					cout << "상점으로 이동합니다. 소지골드 : " << myHero.myGold << "  현재 체력 : " << myHero.myHp << endl;
					cout << "1. 전체 회복(300 gold)" << endl << "2. 30회복(200 gold)"
						<< endl << "3. 20회복(100 gold)" << endl << "4.10회복(50 gold)" << endl << "그 외.Exit" << endl;
					cin >> selecNum;
					switch (selecNum)
					{
					case 1:
						if (myHero.myGold >= goShop.potionCost[selecNum - 1])
						{
							myHero.myGold -= goShop.potionCost[selecNum - 1];
							myHero.myHp = myHero.fullHp;
							break;
						}
						else cout << " 소지 금액이 부족합니다." << endl; Sleep(1000); break;
					case 2:
						if (myHero.myGold >= goShop.potionCost[selecNum - 1])
						{
							myHero.myGold -= goShop.potionCost[selecNum - 1];
							myHero.myHp += goShop.usePotion[selecNum - 1];
							if (myHero.myHp > myHero.fullHp)
							{
								myHero.myHp -= (myHero.myHp - myHero.fullHp);
							}
							break;
						}
						else cout << " 소지 금액이 부족합니다." << endl; Sleep(1000); break;
					case 3:
						if (myHero.myGold >= goShop.potionCost[selecNum - 1])
						{
							myHero.myGold -= goShop.potionCost[selecNum - 1];
							myHero.myHp += goShop.usePotion[selecNum - 1];
							if (myHero.myHp > myHero.fullHp)
							{
								myHero.myHp -= (myHero.myHp - myHero.fullHp);
							}
							break;
						}
						else cout << " 소지 금액이 부족합니다." << endl; Sleep(1000);  break;
					case 4:
						if (myHero.myGold >= goShop.potionCost[selecNum - 1])
						{
							myHero.myGold -= goShop.potionCost[selecNum - 1];
							myHero.myHp += goShop.usePotion[selecNum - 1];
							if (myHero.myHp > myHero.fullHp)
							{
								myHero.myHp -= (myHero.myHp - myHero.fullHp);
							}
							break;
						}
						else { cout << " 소지 금액이 부족합니다." << endl; Sleep(1000); break; }
					case 5:
						break;
					}
					///////////////////////////////////////////////////////////////////////
				}
				else if (myDungeon.monsterNum == 0) cout << "모든 적을 물리쳤습니다! 게임을 종료합니다." << endl; break;
			}
			else if (myDungeon.monsterAtk[atkNum] == myDungeon.myAttack[myAtk-3])
			{
				cout << "몬스터의 공격은 : " << myDungeon.monsterAtk[atkNum] << endl; cout << "패배하였습니다." << endl;
				cout << endl;
				Sleep(1000);
				myHero.myHp -= myDungeon.monsterPower;

				if (myHero.myHp <= 0) cout << "던전을 클리어하지 못하였습니다. " << endl; break;
				Sleep(1000);
				break;
			}
		}
	}
}