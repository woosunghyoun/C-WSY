﻿#include <iostream>
#include <conio.h>
#include <ctime>
#include <Windows.h>
/*
* 영웅은 절차적 2
* 배열/구조체/함수를 최대한 활용해보자.
* 맵의 구성 : 타일로 구성된다.
* 타일에는 종류가 있다. (숲, 늪, 땅)마다 만나는 몬스터가 다르다.
* 타일 : 타일 x좌표, y좌표, 타입, 모양
* 플레이어 : 이름, 최대HP(레벨에 따라 증가), HP(현재), 레벨, 경험치, 소유골드
* 몬스터 : 이름, 최대 HP, HP(현재), 획득할 수 있는 경험치/골드
* 물약 : 이름, 가격, 회복량
* 상점 : 물약의 종류와 수량
* + 알파(환영)
*/

using namespace std;

enum TILETYPE { FOREST, SWAMP, Ground };
enum MODE { EASY = 1, NOMAL, HARD };
struct Player
{
	string name;
	int maxHp;
	int hp;
	int level;
	int maxExp;
	int exp;
	int playerX = 0;
	int playerY = 0;
	int gold; // 현재 가지고있는 골드량
	int inputKey;
	int power;
	char wasdBoard;
};
struct Tile
{
	int posX, posY;
	int type; //0 = 숲, 1 = 늪, 2 = 땅
	char shape; // 0 = 'Y', 1 = 'E', 2 = 'M'
	char Player;
};
struct Monster
{
	string name;
	string MonsterAttack[3] = { "가위","바위","보" };
	int maxHp;
	int hp;
	int gold;
	int power =0;
	int posX ;
	int posY ;
	int exp;
	int count=0;
};
struct Potion
{
	string name;
	int healingPoint;
	int price;
};
struct Store
{
	int count;
	Potion potion;
};
struct GameManager
{
	string name[5] = { "오크","트롤", "고블린", "난쟁이", "놀"};
	int mapSize = 0;
	int monstercount;
	int defLevel;//난이도
	Monster* monster;
};
void SetMap(Tile** map, int size);
void MonsterList(GameManager& gamemanager);
void SetMonster(GameManager& monster, string Name, int maxHp, int Exp, int Gold);
void SetMap(Tile** map, int size);
void PrintMap(Tile** map, Player& player, int size,GameManager m);
int main()
{
	Player player;
	Monster monster;
	//GameManager* gamemanager= new GameManager;
	GameManager gamemanager;
	srand(time(NULL));
	
	cout << " 용사는 절차중 " << endl;
	cout << " ";
	cout << " Play 하실 이름을 입력하세요. " << endl;
	cin >> player.name;
	cout << " Play 하실 난이도를 선택해주세요. (01. Eazy, 02. Nomal, 03. Hard)" << endl;
	cin >> player.inputKey;
		switch (player.inputKey)
		{
			case MODE::EASY:
				gamemanager.monstercount = 10;
				gamemanager.monster = new Monster[gamemanager.monstercount];
		/*		monster.maxHp = 50;*/
			/*	monster.exp = 10;
				monster.gold = rand() % (98 - 1)+1;
				monster.hp = monster.maxHp - monster.hp;
				monster.power = 5;*/
				player.power = 25;
				player.maxHp = 250;
				player.level;
				player.exp;
				player.maxExp;
				gamemanager.mapSize = 10;
				break;
			case MODE::NOMAL:
				gamemanager.monstercount = 15;
				gamemanager.monster = new Monster[gamemanager.monstercount];
			/*	monster.maxHp = 100;*/
				/*monster.exp = 20;
				monster.gold = rand() % (98 - 1) + 1;
				monster.hp = monster.maxHp - monster.hp;
				monster.power = 5;*/
				player.power = 25;
				player.maxHp = 500;
				player.level;
				player.exp;
				player.maxExp;
				gamemanager.mapSize = 15;
				break;
			case MODE::HARD:
				gamemanager.monstercount = 20;
				gamemanager.monster = new Monster[gamemanager.monstercount];
			/*	monster.maxHp = 125;
				monster.exp = 40;
				monster.gold = rand() % (98 - 1) + 1;
				monster.hp = monster.maxHp - monster.hp;
				monster.power = 10;*/
				player.power = 25;
				player.maxHp = 1000;
				player.level;
				player.exp;
				player.maxExp;
				gamemanager.mapSize = 20;
				break;
		}
		//MonsterList(gamemanager);

		Tile** tile = new Tile * [gamemanager.mapSize];   // 2중포인터 동적할당 : Tile이라는 이름의 메모리주소(메모리 내 내용들포함)를  tile 로 사용 
		SetMap(tile, gamemanager.mapSize);

		

		while (1)
		{
			system("cls");
			PrintMap(tile, player, gamemanager.mapSize,gamemanager);
			cout << endl;
			player.wasdBoard = _getch();

			switch (player.wasdBoard)
			{
			case 'w' : case 'W' :
				if (player.playerX > 0) player.playerX -= 1; break;
			case 'a' : case 'A' :
				if (player.playerY > 0) player.playerY -= 1; break;
			case 's' : case 'S' :
				if (player.playerX < gamemanager.mapSize -1) player.playerX += 1; break;   // 맵사이즈는 난이도에 따라 달라짐 10 , 15 ,20  맵사이즈 밖으로 이동이 안되게 하기 위해서 맵에 -1해서 맵에 이동공간을 가둠
			case 'd' : case'D' :
				if (player.playerY < gamemanager.mapSize - 1) player.playerY += 1; break;
			}

			//if (tile[player.playerX][player.playerY].shape == 'M') {

			//	cout << "몬스터를 만났습니다..!" << endl;
			//}

			for (int i = 0; i < gamemanager.monstercount; i++) {
				if (player.playerX == gamemanager.monster[i].posX && player.playerY == gamemanager.monster[i].posY) {
					cout << "몬스터를 만났습니다..!";
					cout << gamemanager.monster[i].name << endl;
					Sleep(1000);
				}
			}
		}	
		system("PAUSE");
		for (int i = 0; i < gamemanager.mapSize; i++)
		{
			delete[] tile[i];
		}
		delete[] tile;	
		/*
		delete[] gamemanager.monster;
		delete gamemanager.;*/
}
void SetMonster(GameManager& m)
{

	for (int i = 0; i < m.monstercount; i++) {
		m.monster[i].posX = rand() % m.mapSize;
		m.monster[i].posY = rand() % m.mapSize;
		//m.monster[i].name = name;
		m.monster[i].name = m.name[rand() % 5];
	}
}
void SetMonster(GameManager& monster, string Name, int maxHp, int Exp, int Gold )
{
	monster.monster[monster.monster->count].name = Name;
	monster.monster[monster.monster->count].maxHp = maxHp;
	monster.monster[monster.monster->count].hp = maxHp; 
	monster.monster[monster.monster->count].exp = Exp;
	monster.monster[monster.monster->count].gold = Gold;
	monster.monster[monster.monster->count].posX = rand() % monster.mapSize;
	monster.monster[monster.monster->count].posY = rand() % monster.mapSize;
	monster.monster->count++;
}
//void MonsterList(GameManager& gamemanager)
//{
//	string name[5] = { "오크","악마","다크엘프","좀비","타락천사" };
//	int randnum;
//	srand(time(NULL));
	
//	for (int i = 0; i < gamemanager.monstercount; i++)
//	{
//		//randnum = rand() % 5;
//		//SetMonster(gamemanager, name[randnum], 50, 10, (rand() % 98 + 1));
//		SetMonster(gamemanager,name[i%5]);
//		cout << gamemanager.monster[i].name << endl;
//	}
//}

void SetMap(Tile** map, int size)
{
	for (int i = 0; i < size; i++)
	{
		map[i] = new Tile[size];
	}
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			map[i][j].posX = i;
			map[i][j].posY = j;
			map[i][j].type = TILETYPE(rand() % 3);
			switch (map[i][j].type)
			{
			case TILETYPE::FOREST:
				map[i][j].shape = 'F';
				break;
			case TILETYPE::SWAMP:
				map[i][j].shape ='S';
				break;
			case TILETYPE::Ground:
				map[i][j].shape = 'G';
				break;	
			}
		}
		cout << endl;
	}
}
void PrintMap(Tile** map, Player& player, int size,GameManager m)
{
	for (int i = 0; i < m.monstercount; i++) {
		map[m.monster[i].posX][m.monster[i].posY].shape = 'M';
	}
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			//map[player.playerX][player.playerY].shape = 'O';
			if (i == player.playerX && j == player.playerY)
				cout << '0';
			else
				cout << map[i][j].shape;
		}
		cout << endl;
	}
}